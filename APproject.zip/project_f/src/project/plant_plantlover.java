/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PLANT_PLANTLOVER")
public class plant_plantlover implements java.io.Serializable{
    @Id
    @Column(name = "plantName")
    private String plantName;
    @Id
    @Column(name="username")
    private String username;
    @Column(name="time")
    private String time;

    public plant_plantlover() {
    }

    public void setTime(String time) {
        this.time = time;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getUsername() {
        return username;
    }

    public String getPlantName() {
        return plantName;
    }

    public String getTime() {
        return time;
    }

    
   
}